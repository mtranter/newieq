"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildUserService = void 0;
var user_service_1 = require("./user-service");
Object.defineProperty(exports, "buildUserService", { enumerable: true, get: function () { return user_service_1.buildUserService; } });
