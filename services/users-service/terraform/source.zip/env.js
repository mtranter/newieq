"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.envOrThrow = void 0;
const envOrThrow = (env) => {
    const envVar = process.env[env];
    if (!envVar) {
        throw new Error(`Expected env var not found: ${env}`);
    }
    else {
        return envVar;
    }
};
exports.envOrThrow = envOrThrow;
