"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const aws_xray_sdk_core_1 = __importDefault(require("aws-xray-sdk-core"));
const dynamo_user_repo_1 = require("./services/dynamo-user-repo");
const user_service_1 = require("./domain/user-service");
const routes_1 = require("./api/routes");
const jwt_1 = require("./api/jwt");
const env_1 = require("./env");
exports.handler = (0, routes_1.buildApi)((0, user_service_1.buildUserService)((0, dynamo_user_repo_1.buildDynamoUserRepo)((0, env_1.envOrThrow)('DYNAMODB_TABLE_NAME'), aws_xray_sdk_core_1.default.captureAWSClient(new aws_sdk_1.DynamoDB())), (0, env_1.envOrThrow)('USEREVENTS_TOPIC_ARN')), (0, jwt_1.buildJwt)((0, env_1.envOrThrow)('JWT_SECRET')));
