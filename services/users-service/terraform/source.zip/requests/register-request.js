"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegisterRequestSchema = void 0;
const typebox_1 = require("@sinclair/typebox");
exports.RegisterRequestSchema = typebox_1.Type.Object({
    username: typebox_1.Type.String({ minLength: 4, maxLength: 64 }),
    password: typebox_1.Type.String({ minLength: 8 })
});
