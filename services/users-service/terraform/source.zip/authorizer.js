"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.index = void 0;
const jwt_1 = require("./api/jwt");
const env_1 = require("./env");
const isTokenEvent = (e) => e.type === 'TOKEN';
const index = (e) => {
    const jwt = (0, jwt_1.buildJwt)((0, env_1.envOrThrow)('JWT_SECRET'));
    const authHeaderValue = isTokenEvent(e) ? e.authorizationToken : e.headers?.['authorization'];
    try {
        const header = authHeaderValue?.substring('token '.length);
        const token = jwt.verify(header);
        const apiId = e.methodArn.split('/')[0];
        return Promise.resolve({
            principalId: token.username,
            policyDocument: {
                Version: '2012-10-17',
                Statement: [
                    {
                        Action: 'execute-api:Invoke',
                        Effect: 'Allow',
                        Resource: `${apiId}/*/*/*`
                    }
                ]
            },
            context: {
                username: token.username
            }
        });
    }
    catch {
        return Promise.resolve({
            principalId: 'unknown',
            policyDocument: {
                Version: '2012-10-17',
                Statement: [
                    {
                        Action: 'execute-api:Invoke',
                        Effect: 'Allow',
                        Resource: e.methodArn
                    }
                ]
            }
        });
    }
};
exports.index = index;
